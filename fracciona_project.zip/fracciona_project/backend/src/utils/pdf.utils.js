import PDFDocument from 'pdfkit';
import fs from 'fs';
export async function generarPDF(dictamen, proyecto) {
  const doc = new PDFDocument();
  const ruta = `./pdfs/dictamen_${dictamen.id}.pdf`;
  if (!fs.existsSync('./pdfs')) fs.mkdirSync('./pdfs');
  doc.pipe(fs.createWriteStream(ruta));
  doc.fontSize(16).text('DICTAMEN FRACCIONA', { align: 'center' });
  doc.moveDown();
  doc.fontSize(12).text(`Resultado: ${dictamen.resultado}`);
  doc.text(`Resumen: ${dictamen.resumen}`);
  doc.end();
  return ruta;
}
