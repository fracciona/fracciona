import { Router } from 'express';
import { crearProyecto, listarProyectos, obtenerProyecto } from '../controllers/proyectos.controller.js';
const router = Router();

router.post('/', crearProyecto);
router.get('/', listarProyectos);
router.get('/:id', obtenerProyecto);

export default router;
