import { Router } from 'express';
import { generarDictamen } from '../controllers/dictamenes.controller.js';
const router = Router();

router.post('/generar', generarDictamen);

export default router;
