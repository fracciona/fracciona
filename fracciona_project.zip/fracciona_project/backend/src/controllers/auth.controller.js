import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

export const registerController = async (req, res) => {
  try {
    const { nombre, email, password, rol } = req.body;
    const hash = await bcrypt.hash(password, 10);
    const user = await prisma.usuario.create({
      data: { nombre, email, password: hash, rol }
    });
    res.json({ ok: true, user: { id: user.id, email: user.email }});
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

export const loginController = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await prisma.usuario.findUnique({ where: { email }});
    if (!user) return res.status(404).json({ error: 'Usuario no encontrado' });
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ error: 'Contraseña incorrecta' });
    const token = jwt.sign({ id: user.id, rol: user.rol }, process.env.JWT_SECRET || 'devsecret', { expiresIn: '8h' });
    res.json({ token, user: { id: user.id, email: user.email, nombre: user.nombre, rol: user.rol }});
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
