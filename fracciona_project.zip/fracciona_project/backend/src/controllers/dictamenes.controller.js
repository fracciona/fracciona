import { PrismaClient } from '@prisma/client';
import { generarPDF } from '../utils/pdf.utils.js';
const prisma = new PrismaClient();

export const generarDictamen = async (req, res) => {
  try {
    const { proyectoId, datosProyecto } = req.body;
    // load reglas (simple demo: all reglas)
    const reglas = await prisma.regla.findMany();
    const reglasAplicadas = reglas.map(r => {
      // evaluate condition in safe manner - for demo we'll use Function (note: in prod use parser)
      let cumple = true;
      try {
        const fn = new Function('data', `return (${r.condicion});`);
        cumple = Boolean(fn(datosProyecto));
      } catch (e) {
        cumple = false;
      }
      return { regla: r.titulo, cumple };
    });

    const cumpleTodo = reglasAplicadas.every(r => r.cumple);
    const resultado = cumpleTodo ? 'POSITIVO' : 'NEGATIVO';
    const resumen = cumpleTodo ? 'Cumple con todas las reglas.' : 'Existen incumplimientos.';

    const dictamen = await prisma.dictamen.create({
      data: {
        proyectoId,
        resultado,
        resumen,
        pdfUrl: null
      }
    });

    // (generate PDF file - placeholder)
    // const pdfPath = await generarPDF(dictamen, datosProyecto);
    // await prisma.dictamen.update({ where: { id: dictamen.id }, data: { pdfUrl: pdfPath }});

    res.json({ resultado, reglasAplicadas, resumen, dictamenId: dictamen.id });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
