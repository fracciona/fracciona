import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

export const crearProyecto = async (req, res) => {
  try {
    const data = req.body;
    const p = await prisma.proyecto.create({ data });
    res.json(p);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

export const listarProyectos = async (_, res) => {
  try {
    const list = await prisma.proyecto.findMany();
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};

export const obtenerProyecto = async (req, res) => {
  try {
    const id = Number(req.params.id);
    const p = await prisma.proyecto.findUnique({ where: { id }});
    if (!p) return res.status(404).json({ error: 'No encontrado' });
    res.json(p);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
