import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  const hash = await bcrypt.hash("Admin!12345", 10);

  await prisma.usuario.upsert({
    where: { email: "admin@fracciona.local" },
    update: {},
    create: {
      nombre: "Administrador FRACCIONA",
      email: "admin@fracciona.local",
      password: hash,
      rol: "admin"
    }
  });

  await prisma.municipio.createMany({
    data: [
      { nombre: "Tepic" },
      { nombre: "Xalisco" },
      { nombre: "San Blas" }
    ]
  });

  console.log("Seed finalizado.");
}
main().catch(e => {
  console.error(e);
  process.exit(1);
}).finally(async () => {
  await prisma.$disconnect();
});
