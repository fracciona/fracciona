import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import Generar from './pages/Generar';

export default function App(){
  return (
    <BrowserRouter>
      <nav style={{ padding: 10, borderBottom: '1px solid #ccc' }}>
        <Link to="/">Inicio</Link> | <Link to="/generar">Generar Dictamen</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/generar" element={<Generar/>} />
      </Routes>
    </BrowserRouter>
  );
}
