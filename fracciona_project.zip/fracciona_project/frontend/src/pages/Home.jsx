import React from 'react';
export default function Home(){
  return (
    <div style={{ padding: 20 }}>
      <h1>FRACCIONA</h1>
      <p>Bienvenido al sistema de dictaminación.</p>
    </div>
  );
}
