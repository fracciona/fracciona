import React, { useState } from 'react';
import axios from 'axios';
export default function Generar(){
  const [data, setData] = useState({ superficie: 0, lotes: 0 });
  const [res, setRes] = useState(null);

  const enviar = async () => {
    try {
      const r = await axios.post((import.meta.env.VITE_API_BASE || 'http://localhost:3000') + '/dictamenes/generar', {
        proyectoId: 1,
        datosProyecto: data
      });
      setRes(r.data);
    } catch (e) {
      alert('Error: ' + e.message);
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Generar dictamen</h2>
      <div>
        <label>Superficie (m2)</label>
        <input type="number" value={data.superficie} onChange={e=>setData({...data, superficie: +e.target.value})} />
      </div>
      <div>
        <label>Lotes</label>
        <input type="number" value={data.lotes} onChange={e=>setData({...data, lotes: +e.target.value})} />
      </div>
      <button onClick={enviar}>Evaluar</button>

      {res && <pre>{JSON.stringify(res, null, 2)}</pre>}
    </div>
  );
}
